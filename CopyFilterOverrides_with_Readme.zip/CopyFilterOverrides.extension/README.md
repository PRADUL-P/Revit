# Copy Filter Overrides (pyRevit Extension)

## 📌 Overview
This pyRevit extension adds a button to Revit that allows you to **copy filter overrides** (line color, hatch, fill pattern, transparency, etc.) from one filter in the active view to one or more other filters.

This helps speed up large projects where multiple filters need the same graphic settings.

---

## 🔹 Installation Steps
1. Download and extract the ZIP file into your pyRevit extensions folder:
   ```
   %appdata%\pyRevit\Extensions
   ```

2. After extraction, the folder structure should look like this:
   ```
   CopyFilterOverrides.extension
       └── CopyFilterOverrides.tab
           └── Tools.panel
               └── CopyOverrides.pushbutton
                   ├── script.py
                   └── script.pushbutton
   ```

3. Open Revit and go to:
   - **pyRevit > Reload**

4. You should now see a new button:
   - **Copy Filter Overrides** under the **Tools** panel.

---

## 🔹 Usage Instructions
1. Open a view that already has filters applied.  
2. Manually set the correct overrides (color, hatch, line type, etc.) on **one filter**.  
3. Click **Copy Filter Overrides**.  
4. Select the **source filter** (the one with correct overrides).  
5. Select one or more **target filters** (the ones you want to update).  
6. The overrides will be copied automatically. ✅

---

## 🔹 Notes
- Works per **active view** (filters must be applied in that view).  
- If no filters are found, you’ll get an error message.  
- Multiple target filters can be selected at once.  

---

## ✨ Author
Developed by **ChatGPT** (for PRADUL P)
