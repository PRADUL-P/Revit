# -*- coding: utf-8 -*-
"""
Copy Filter Overrides
Author: ChatGPT (for PRADUL P)
Description: Copies line color, fill, pattern, and other overrides 
from a selected source filter in the active view and pastes them 
to selected target filters.
"""

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import forms

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document
view = doc.ActiveView

def get_filter_names(filters):
    """Return {filterId: name} dict"""
    names = {}
    for f in filters:
        filt_elem = doc.GetElement(f)
        names[f] = filt_elem.Name
    return names

# Get filters applied to active view
filters = view.GetFilters()
if not filters:
    TaskDialog.Show("Error", "No filters applied to this view.")
    quit()

# Build dict of {Id:Name}
filter_dict = get_filter_names(filters)

# Ask user to pick source filter from list
source_name = forms.SelectFromList.show(
    [filter_dict[fid] for fid in filter_dict],
    title="Select Source Filter",
    multiselect=False
)

if not source_name:
    quit()

# Find filterId for chosen name
source_filter_id = None
for fid, name in filter_dict.items():
    if name == source_name:
        source_filter_id = fid
        break

if not source_filter_id:
    TaskDialog.Show("Error", "Could not find selected filter.")
    quit()

# Get overrides from source filter
source_ogs = view.GetFilterOverrides(source_filter_id)

# Ask which target filters to apply to
target_names = forms.SelectFromList.show(
    [name for fid, name in filter_dict.items() if fid != source_filter_id],
    title="Select Target Filters (multi-select)",
    multiselect=True
)

if not target_names:
    TaskDialog.Show("Info", "No targets selected.")
    quit()

# Collect target IDs
target_ids = []
for fid, name in filter_dict.items():
    if name in target_names:
        target_ids.append(fid)

# Apply overrides
t = Transaction(doc, "Copy Filter Overrides")
t.Start()
for fid in target_ids:
    view.SetFilterOverrides(fid, source_ogs)
t.Commit()

TaskDialog.Show("Done", "Copied overrides from '{}' to {} target filter(s).".format(source_name, len(target_ids)))
